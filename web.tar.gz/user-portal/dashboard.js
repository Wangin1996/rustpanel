'use strict';

(function registerDashboard() {
  /* ─── Pure Zero-Dependency Offline QR Code Encoder (ISO/IEC 18004 Byte Mode, ECC L, v1..12) ─── */
  const TOTAL_CODEWORDS = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466];
  const EC_CODEWORDS_PER_BLOCK = [0, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24];
  const NUM_BLOCKS = [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4];
  const ALIGNMENT_POS = [
    [],
    [],
    [6, 18],
    [6, 22],
    [6, 26],
    [6, 30],
    [6, 34],
    [6, 22, 38],
    [6, 24, 42],
    [6, 26, 46],
    [6, 28, 50],
    [6, 30, 54],
    [6, 32, 58],
  ];

  const GF_EXP = new Uint8Array(512);
  const GF_LOG = new Uint8Array(256);
  (function initGfTables() {
    let x = 1;
    for (let i = 0; i < 255; i++) {
      GF_EXP[i] = x;
      GF_LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
    for (let i = 255; i < 512; i++) GF_EXP[i] = GF_EXP[i - 255];
  })();

  function gfMul(a, b) {
    if (a === 0 || b === 0) return 0;
    return GF_EXP[GF_LOG[a] + GF_LOG[b]];
  }

  function rsCompute(data, ecLen) {
    let gen = [1];
    for (let i = 0; i < ecLen; i++) {
      const next = new Array(gen.length + 1).fill(0);
      const root = GF_EXP[i];
      for (let j = 0; j < gen.length; j++) {
        next[j] ^= gen[j];
        next[j + 1] ^= gfMul(gen[j], root);
      }
      gen = next;
    }
    const rem = new Array(ecLen).fill(0);
    for (let idx = 0; idx < data.length; idx++) {
      const factor = data[idx] ^ rem[0];
      rem.shift();
      rem.push(0);
      for (let j = 0; j < ecLen; j++) {
        rem[j] ^= gfMul(gen[j + 1], factor);
      }
    }
    return rem;
  }

  function encodeQrMatrix(text) {
    if (!text) return null;
    const bytes = Array.from(new TextEncoder().encode(text));
    if (bytes.length === 0) return null;

    let ver = 1;
    while (ver <= 12) {
      const dataCap = TOTAL_CODEWORDS[ver] - EC_CODEWORDS_PER_BLOCK[ver] * NUM_BLOCKS[ver];
      const headerBits = ver <= 9 ? 12 : 20;
      if (bytes.length * 8 + headerBits <= dataCap * 8) break;
      ver++;
    }
    if (ver > 12) return null;

    const totalCw = TOTAL_CODEWORDS[ver];
    const ecPerBlock = EC_CODEWORDS_PER_BLOCK[ver];
    const numBlocks = NUM_BLOCKS[ver];
    const dataCwLen = totalCw - ecPerBlock * numBlocks;

    const bits = [];
    function pushBits(val, len) {
      for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1);
    }

    pushBits(0b0100, 4);
    pushBits(bytes.length, ver <= 9 ? 8 : 16);
    for (let i = 0; i < bytes.length; i++) pushBits(bytes[i], 8);

    const maxBits = dataCwLen * 8;
    pushBits(0, Math.min(4, maxBits - bits.length));
    while (bits.length % 8 !== 0) bits.push(0);

    const dataCw = [];
    for (let i = 0; i < bits.length; i += 8) {
      let b = 0;
      for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j];
      dataCw.push(b);
    }
    let padToggle = 0;
    while (dataCw.length < dataCwLen) {
      dataCw.push(padToggle === 0 ? 0xec : 0x11);
      padToggle ^= 1;
    }

    const shortBlockLen = Math.floor(dataCwLen / numBlocks);
    const numLongBlocks = dataCwLen % numBlocks;
    const numShortBlocks = numBlocks - numLongBlocks;

    const dataBlocks = [];
    const ecBlocks = [];
    let offset = 0;
    for (let i = 0; i < numBlocks; i++) {
      const len = shortBlockLen + (i >= numShortBlocks ? 1 : 0);
      const block = dataCw.slice(offset, offset + len);
      offset += len;
      dataBlocks.push(block);
      ecBlocks.push(rsCompute(block, ecPerBlock));
    }

    const finalCw = [];
    const maxDataLen = shortBlockLen + (numLongBlocks > 0 ? 1 : 0);
    for (let i = 0; i < maxDataLen; i++) {
      for (let b = 0; b < numBlocks; b++) {
        if (i < dataBlocks[b].length) finalCw.push(dataBlocks[b][i]);
      }
    }
    for (let i = 0; i < ecPerBlock; i++) {
      for (let b = 0; b < numBlocks; b++) finalCw.push(ecBlocks[b][i]);
    }

    const size = ver * 4 + 17;
    const modules = Array.from({ length: size }, () => new Array(size).fill(false));
    const isFunc = Array.from({ length: size }, () => new Array(size).fill(false));

    function setFunc(r, c, dark) {
      if (r < 0 || r >= size || c < 0 || c >= size) return;
      modules[r][c] = dark;
      isFunc[r][c] = true;
    }

    function drawFinder(r0, c0) {
      for (let dr = -1; dr <= 7; dr++) {
        for (let dc = -1; dc <= 7; dc++) {
          const inOuter = dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6;
          const onRing = dr === 0 || dr === 6 || dc === 0 || dc === 6;
          const inCore = dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4;
          setFunc(r0 + dr, c0 + dc, inOuter && (onRing || inCore));
        }
      }
    }

    drawFinder(0, 0);
    drawFinder(0, size - 7);
    drawFinder(size - 7, 0);

    for (let i = 8; i < size - 8; i++) {
      setFunc(6, i, i % 2 === 0);
      setFunc(i, 6, i % 2 === 0);
    }

    const aligns = ALIGNMENT_POS[ver];
    for (let i = 0; i < aligns.length; i++) {
      for (let j = 0; j < aligns.length; j++) {
        if (
          (i === 0 && j === 0) ||
          (i === 0 && j === aligns.length - 1) ||
          (i === aligns.length - 1 && j === 0)
        ) {
          continue;
        }
        const cr = aligns[i];
        const cc = aligns[j];
        for (let dr = -2; dr <= 2; dr++) {
          for (let dc = -2; dc <= 2; dc++) {
            setFunc(cr + dr, cc + dc, Math.max(Math.abs(dr), Math.abs(dc)) !== 1);
          }
        }
      }
    }

    for (let i = 0; i <= 8; i++) {
      if (i !== 6) {
        setFunc(8, i, false);
        setFunc(i, 8, false);
      }
    }
    for (let i = 0; i < 8; i++) {
      setFunc(8, size - 1 - i, false);
      setFunc(size - 1 - i, 8, false);
    }
    setFunc(size - 8, 8, true);

    if (ver >= 7) {
      let rem = ver;
      for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25);
      const vBits = (ver << 12) | rem;
      for (let i = 0; i < 18; i++) {
        const bit = ((vBits >>> i) & 1) === 1;
        const a = size - 11 + (i % 3);
        const b = Math.floor(i / 3);
        setFunc(a, b, bit);
        setFunc(b, a, bit);
      }
    }

    let bitIdx = 0;
    const totalBits = finalCw.length * 8;
    let upward = true;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let vert = 0; vert < size; vert++) {
        const r = upward ? size - 1 - vert : vert;
        for (let j = 0; j < 2; j++) {
          const c = right - j;
          if (!isFunc[r][c]) {
            let dark = false;
            if (bitIdx < totalBits) {
              dark = ((finalCw[bitIdx >>> 3] >>> (7 - (bitIdx & 7))) & 1) === 1;
              bitIdx++;
            }
            if ((r + c) % 2 === 0) dark = !dark;
            modules[r][c] = dark;
          }
        }
      }
      upward = !upward;
    }

    let fRem = 0b01000;
    for (let i = 0; i < 10; i++) fRem = (fRem << 1) ^ ((fRem >>> 9) * 0x537);
    const formatBits = ((0b01000 << 10) | fRem) ^ 0x5412;

    const getFormatBit = (i) => ((formatBits >>> i) & 1) === 1;
    for (let i = 0; i <= 5; i++) modules[8][i] = getFormatBit(i);
    modules[8][7] = getFormatBit(6);
    modules[8][8] = getFormatBit(7);
    modules[7][8] = getFormatBit(8);
    for (let i = 9; i < 15; i++) modules[14 - i][8] = getFormatBit(i);

    for (let i = 0; i < 8; i++) modules[size - 1 - i][8] = getFormatBit(i);
    for (let i = 8; i < 15; i++) modules[8][size - 15 + i] = getFormatBit(i);
    modules[size - 8][8] = true;

    return modules;
  }

  function renderQrSvgMarkup(value) {
    const matrix = encodeQrMatrix(value);
    if (!matrix) {
      return '<div class="qr-fallback">订阅地址过长，请直接复制链接导入</div>';
    }
    const n = matrix.length;
    const quiet = 3;
    const viewSize = n + quiet * 2;
    const paths = [];
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (matrix[r][c]) {
          paths.push('M' + (c + quiet) + ',' + (r + quiet) + 'h1v1h-1z');
        }
      }
    }
    return (
      '<svg viewBox="0 0 ' + viewSize + ' ' + viewSize + '" shape-rendering="crispEdges" role="img" aria-label="订阅二维码">' +
        '<rect width="' + viewSize + '" height="' + viewSize + '" fill="#ffffff"/>' +
        '<path d="' + paths.join('') + '" fill="#09090b"/>' +
      '</svg>'
    );
  }

  /* ─── Inline Cross-Platform Vector SVG Flag Renderer ─── */
  const REGION_NAMES = {
    HK: '香港', TW: '台湾', MO: '澳门', CN: '中国大陆', JP: '日本', KR: '韩国', SG: '新加坡',
    MY: '马来西亚', TH: '泰国', VN: '越南', PH: '菲律宾', ID: '印尼', IN: '印度', PK: '巴基斯坦',
    AE: '阿联酋', IL: '以色列', TR: '土耳其', US: '美国', CA: '加拿大', MX: '墨西哥', BR: '巴西',
    AR: '阿根廷', CL: '智利', GB: '英国', DE: '德国', FR: '法国', NL: '荷兰', CH: '瑞士',
    SE: '瑞典', NO: '挪威', FI: '芬兰', DK: '丹麦', PL: '波兰', AT: '奥地利', IT: '意大利',
    ES: '西班牙', PT: '葡萄牙', IE: '爱尔兰', BE: '比利时', LU: '卢森堡', IS: '冰岛', RO: '罗马尼亚',
    BG: '保加利亚', RU: '俄罗斯', UA: '乌克兰', AU: '澳大利亚', NZ: '新西兰', ZA: '南非',
  };

  const KEYWORD_TO_ISO = [
    [/(香港|hong\s*kong|\bhk\b|\bhkg\b)/i, 'HK'],
    [/(台湾|台灣|台北|新北|台中|高雄|taiwan|taipei|\btw\b|\btpe\b)/i, 'TW'],
    [/(澳门|澳門|macao|macau|\bmo\b)/i, 'MO'],
    [/(日本|东京|大阪|名古屋|japan|tokyo|osaka|\bjp\b|\bnrt\b|\bkix\b|\btyo\b)/i, 'JP'],
    [/(韩国|韓國|首尔|釜山|春川|korea|seoul|\bkr\b|\bicn\b)/i, 'KR'],
    [/(新加坡|狮城|singapore|\bsg\b|\bsin\b)/i, 'SG'],
    [/(美国|美國|洛杉矶|圣何塞|西雅图|硅谷|纽约|达拉斯|芝加哥|凤凰城|波特兰|弗吉尼亚|亚特兰大|united\s*states|\busa\b|\bus\b|\blax\b|\bsjc\b|\bsea\b|\bewr\b|\bdfw\b|\bord\b|\biad\b)/i, 'US'],
    [/(英国|英國|伦敦|曼彻斯特|london|united\s*kingdom|\buk\b|\bgb\b|\blhr\b)/i, 'GB'],
    [/(德国|德國|法兰克福|慕尼黑|柏林|germany|frankfurt|\bde\b|\bfra\b)/i, 'DE'],
    [/(法国|法國|巴黎|马赛|france|paris|\bfr\b|\bcdg\b)/i, 'FR'],
    [/(荷兰|荷蘭|阿姆斯特丹|netherlands|amsterdam|\bnl\b|\bams\b)/i, 'NL'],
    [/(加拿大|多伦多|温哥华|蒙特利尔|canada|toronto|vancouver|\bca\b|\byyz\b|\byvr\b)/i, 'CA'],
    [/(澳大利亚|澳洲|悉尼|墨尔本|australia|sydney|melbourne|\bau\b|\bsyd\b)/i, 'AU'],
    [/(俄罗斯|莫斯科|圣彼得堡|海参崴|新西伯利亚|russia|moscow|\bru\b)/i, 'RU'],
    [/(马来西亚|吉隆坡|malaysia|\bmy\b|\bkul\b)/i, 'MY'],
    [/(泰国|曼谷|thailand|bangkok|\bth\b|\bbkk\b)/i, 'TH'],
    [/(越南|胡志明|河内|vietnam|\bvn\b|\bsgn\b)/i, 'VN'],
    [/(菲律宾|马尼拉|philippines|manila|\bph\b|\bmnl\b)/i, 'PH'],
    [/(印尼|印度尼西亚|雅加达|indonesia|jakarta|\bid\b|\bcgk\b)/i, 'ID'],
    [/(印度|孟买|新德里|班加罗尔|india|mumbai|\bin\b|\bbom\b)/i, 'IN'],
    [/(土耳其|伊斯坦布尔|turkey|turkiye|istanbul|\btr\b|\bist\b)/i, 'TR'],
    [/(阿联酋|迪拜|dubai|\bae\b|\bdxb\b)/i, 'AE'],
    [/(瑞士|苏黎世|switzerland|zurich|\bch\b|\bzrh\b)/i, 'CH'],
    [/(瑞典|斯德哥尔摩|sweden|stockholm|\bse\b|\barn\b)/i, 'SE'],
    [/(波兰|华沙|poland|warsaw|\bpl\b|\bwaw\b)/i, 'PL'],
    [/(意大利|米兰|罗马|italy|milan|\bit\b|\bmxp\b)/i, 'IT'],
    [/(西班牙|马德里|spain|madrid|\bes\b|\bmad\b)/i, 'ES'],
    [/(爱尔兰|都柏林|ireland|dublin|\bie\b|\bdub\b)/i, 'IE'],
    [/(巴西|圣保罗|brazil|\bbr\b|\bgru\b)/i, 'BR'],
    [/(阿根廷|布宜诺斯艾利斯|argentina|\bar\b)/i, 'AR'],
    [/(智利|圣地亚哥|chile|\bcl\b)/i, 'CL'],
    [/(新西兰|奥克兰|new\s*zealand|auckland|\bnz\b|\bakl\b)/i, 'NZ'],
    [/(南非|约翰内斯堡|south\s*africa|\bza\b)/i, 'ZA'],
    [/(中国|深圳|广州|上海|北京|杭州|成都|china|\bcn\b)/i, 'CN'],
  ];

  function emojiFlagToIso(text) {
    if (!text) return null;
    const match = String(text).match(/([\u{1F1E6}-\u{1F1FF}])([\u{1F1E6}-\u{1F1FF}])/u);
    if (!match) return null;
    const a = match[1].codePointAt(0) - 0x1f1e6 + 65;
    const b = match[2].codePointAt(0) - 0x1f1e6 + 65;
    return String.fromCharCode(a, b);
  }

  function stripEmojiFlags(text) {
    if (!text) return '';
    return String(text)
      .replace(/[\u{1F1E6}-\u{1F1FF}]{2}\s*/gu, '')
      .replace(/^\[\s*[A-Za-z]{2}\s*\]\s*/, '')
      .trim();
  }

  function inferRegionCode(node) {
    if (!node) return null;
    const candidates = [node.country_code, node.sort_country, node.region];
    for (let i = 0; i < candidates.length; i++) {
      const raw = candidates[i];
      if (raw && /^[A-Za-z]{2}$/.test(String(raw).trim())) {
        const upper = String(raw).trim().toUpperCase();
        if (upper !== 'ZZ' && upper !== 'XX' && upper !== 'UN') {
          return upper === 'UK' ? 'GB' : upper;
        }
      }
    }
    const fromEmoji = emojiFlagToIso(node.name);
    if (fromEmoji) return fromEmoji === 'UK' ? 'GB' : fromEmoji;
    const bracketMatch = String(node.name || '').match(/^\[\s*([A-Za-z]{2})\s*\]/);
    if (bracketMatch) {
      const upper = bracketMatch[1].toUpperCase();
      return upper === 'UK' ? 'GB' : upper;
    }
    const combined = (node.name || '') + ' ' + (node.host || '');
    for (let i = 0; i < KEYWORD_TO_ISO.length; i++) {
      if (KEYWORD_TO_ISO[i][0].test(combined)) return KEYWORD_TO_ISO[i][1];
    }
    return null;
  }

  function flagSvgInner(code) {
    switch (code) {
      case 'HK':
        return '<rect width="24" height="16" fill="#de2910"/><circle cx="12" cy="8" r="4.3" fill="none" stroke="#ffffff" stroke-width="1.35" stroke-dasharray="3.4 1.9"/><circle cx="12" cy="8" r="1.4" fill="#ffffff"/>';
      case 'CN':
        return '<rect width="24" height="16" fill="#de2910"/><circle cx="5.2" cy="4.8" r="2.1" fill="#ffde00"/><circle cx="9.4" cy="2.6" r="0.75" fill="#ffde00"/><circle cx="10.8" cy="4.3" r="0.75" fill="#ffde00"/><circle cx="10.6" cy="6.5" r="0.75" fill="#ffde00"/><circle cx="9.1" cy="8.1" r="0.75" fill="#ffde00"/>';
      case 'TW':
        return '<rect width="24" height="16" fill="#fe0000"/><rect width="12" height="8.5" fill="#000095"/><circle cx="6" cy="4.25" r="2.2" fill="#ffffff"/>';
      case 'MO':
        return '<rect width="24" height="16" fill="#00785e"/><circle cx="12" cy="8.2" r="3.4" fill="none" stroke="#ffffff" stroke-width="1.3"/><circle cx="12" cy="4.2" r="0.9" fill="#ffde00"/>';
      case 'JP':
        return '<rect width="24" height="16" fill="#ffffff"/><circle cx="12" cy="8" r="4.4" fill="#bc002d"/>';
      case 'KR':
        return '<rect width="24" height="16" fill="#ffffff"/><circle cx="12" cy="8" r="3.9" fill="#cd2e3a"/><path d="M8.1 8a3.9 3.9 0 0 0 7.8 0Z" fill="#0047a0"/><path d="M4.2 3.5l2.2 1.5M17.6 3.5l2.2 1.5M4.2 12.5l2.2-1.5M17.6 12.5l2.2-1.5" stroke="#111827" stroke-width="1.1"/>';
      case 'SG':
        return '<rect width="24" height="8" fill="#ef3340"/><rect y="8" width="24" height="8" fill="#ffffff"/><circle cx="6.2" cy="4.1" r="2.5" fill="#ffffff"/><circle cx="7.2" cy="4.1" r="2.2" fill="#ef3340"/>';
      case 'US':
        return '<rect width="24" height="16" fill="#b22234"/><path d="M0 2.4h24M0 5.1h24M0 7.8h24M0 10.5h24M0 13.2h24" stroke="#ffffff" stroke-width="1.25"/><rect width="10.8" height="8.6" fill="#3c3b6e"/><circle cx="3" cy="2.6" r="0.7" fill="#ffffff"/><circle cx="6" cy="4.4" r="0.7" fill="#ffffff"/><circle cx="8.5" cy="2.6" r="0.7" fill="#ffffff"/><circle cx="3.5" cy="6.2" r="0.7" fill="#ffffff"/><circle cx="8" cy="6.2" r="0.7" fill="#ffffff"/>';
      case 'GB':
        return '<rect width="24" height="16" fill="#012169"/><path d="M0 0L24 16M24 0L0 16" stroke="#ffffff" stroke-width="2.8"/><path d="M0 0L24 16M24 0L0 16" stroke="#c8102e" stroke-width="1.3"/><path d="M12 0v16M0 8h24" stroke="#ffffff" stroke-width="4.4"/><path d="M12 0v16M0 8h24" stroke="#c8102e" stroke-width="2.4"/>';
      case 'DE':
        return '<rect width="24" height="5.34" fill="#111111"/><rect y="5.33" width="24" height="5.34" fill="#dd0000"/><rect y="10.66" width="24" height="5.34" fill="#ffce00"/>';
      case 'FR':
        return '<rect width="8" height="16" fill="#002395"/><rect x="8" width="8" height="16" fill="#ffffff"/><rect x="16" width="8" height="16" fill="#ed2939"/>';
      case 'NL':
        return '<rect width="24" height="5.34" fill="#ae1c28"/><rect y="5.33" width="24" height="5.34" fill="#ffffff"/><rect y="10.66" width="24" height="5.34" fill="#21468b"/>';
      case 'RU':
        return '<rect width="24" height="5.34" fill="#ffffff"/><rect y="5.33" width="24" height="5.34" fill="#0039a6"/><rect y="10.66" width="24" height="5.34" fill="#d52b1e"/>';
      case 'UA':
        return '<rect width="24" height="8" fill="#005bbb"/><rect y="8" width="24" height="8" fill="#ffd500"/>';
      case 'IT':
        return '<rect width="8" height="16" fill="#009246"/><rect x="8" width="8" height="16" fill="#ffffff"/><rect x="16" width="8" height="16" fill="#ce2b37"/>';
      case 'IE':
        return '<rect width="8" height="16" fill="#169b62"/><rect x="8" width="8" height="16" fill="#ffffff"/><rect x="16" width="8" height="16" fill="#ff883e"/>';
      case 'BE':
        return '<rect width="8" height="16" fill="#000000"/><rect x="8" width="8" height="16" fill="#fae042"/><rect x="16" width="8" height="16" fill="#ed2939"/>';
      case 'RO':
        return '<rect width="8" height="16" fill="#002b7f"/><rect x="8" width="8" height="16" fill="#fcd116"/><rect x="16" width="8" height="16" fill="#ce1126"/>';
      case 'ES':
        return '<rect width="24" height="4" fill="#aa151b"/><rect y="4" width="24" height="8" fill="#f1bf00"/><rect y="12" width="24" height="4" fill="#aa151b"/>';
      case 'CH':
        return '<rect width="24" height="16" fill="#d52b1e"/><path d="M12 3.5v9M7.5 8h9" stroke="#ffffff" stroke-width="2.8"/>';
      case 'SE':
        return '<rect width="24" height="16" fill="#006aa7"/><path d="M8.5 0v16M0 8h24" stroke="#fecc02" stroke-width="3"/>';
      case 'NO':
        return '<rect width="24" height="16" fill="#ba0c2f"/><path d="M8.5 0v16M0 8h24" stroke="#ffffff" stroke-width="4"/><path d="M8.5 0v16M0 8h24" stroke="#00205b" stroke-width="2"/>';
      case 'FI':
        return '<rect width="24" height="16" fill="#ffffff"/><path d="M8.5 0v16M0 8h24" stroke="#003580" stroke-width="3.2"/>';
      case 'DK':
        return '<rect width="24" height="16" fill="#c8102e"/><path d="M8.5 0v16M0 8h24" stroke="#ffffff" stroke-width="2.8"/>';
      case 'PL':
        return '<rect width="24" height="8" fill="#ffffff"/><rect y="8" width="24" height="8" fill="#dc143c"/>';
      case 'ID':
        return '<rect width="24" height="8" fill="#ce1126"/><rect y="8" width="24" height="8" fill="#ffffff"/>';
      case 'AT':
        return '<rect width="24" height="5.34" fill="#ed2939"/><rect y="5.33" width="24" height="5.34" fill="#ffffff"/><rect y="10.66" width="24" height="5.34" fill="#ed2939"/>';
      case 'TH':
        return '<rect width="24" height="16" fill="#a51931"/><rect y="2.7" width="24" height="10.6" fill="#f4f5f8"/><rect y="5.3" width="24" height="5.4" fill="#2d2a4a"/>';
      case 'VN':
        return '<rect width="24" height="16" fill="#da251d"/><polygon points="12,3.4 13.3,7 17.1,7 14,9.2 15.2,12.8 12,10.6 8.8,12.8 10,9.2 6.9,7 10.7,7" fill="#ffff00"/>';
      case 'MY':
        return '<rect width="24" height="16" fill="#cc0001"/><path d="M0 2.5h24M0 5.5h24M0 8.5h24M0 11.5h24M0 14.5h24" stroke="#ffffff" stroke-width="1.3"/><rect width="12" height="9" fill="#010066"/><circle cx="5.4" cy="4.5" r="2.4" fill="#ffcc00"/><circle cx="6.3" cy="4.5" r="2" fill="#010066"/>';
      case 'IN':
        return '<rect width="24" height="5.34" fill="#ff9933"/><rect y="5.33" width="24" height="5.34" fill="#ffffff"/><rect y="10.66" width="24" height="5.34" fill="#138808"/><circle cx="12" cy="8" r="1.9" fill="none" stroke="#000080" stroke-width="1"/>';
      case 'CA':
        return '<rect width="6" height="16" fill="#ff0000"/><rect x="6" width="12" height="16" fill="#ffffff"/><rect x="18" width="6" height="16" fill="#ff0000"/><polygon points="12,3.5 14.8,8.5 13,8.5 13,12.5 11,12.5 11,8.5 9.2,8.5" fill="#ff0000"/>';
      case 'AU':
      case 'NZ': {
        const star = code === 'NZ' ? '#cc142b' : '#ffffff';
        return '<rect width="24" height="16" fill="#00008b"/><path d="M0 0L11 7.5M11 0L0 7.5" stroke="#ffffff" stroke-width="1.6"/><path d="M5.5 0v7.5M0 3.75h11" stroke="#ffffff" stroke-width="2.4"/><path d="M5.5 0v7.5M0 3.75h11" stroke="#cc142b" stroke-width="1.3"/><circle cx="6" cy="12" r="1.5" fill="#ffffff"/><circle cx="18" cy="4.5" r="1" fill="' + star + '"/><circle cx="18" cy="11.5" r="1.1" fill="' + star + '"/><circle cx="15" cy="8" r="0.9" fill="' + star + '"/>';
      }
      case 'TR':
        return '<rect width="24" height="16" fill="#e30a17"/><circle cx="9.8" cy="8" r="3.6" fill="#ffffff"/><circle cx="11" cy="8" r="2.9" fill="#e30a17"/><circle cx="14.6" cy="8" r="1.2" fill="#ffffff"/>';
      case 'BR':
        return '<rect width="24" height="16" fill="#009c3b"/><polygon points="12,2.2 21,8 12,13.8 3,8" fill="#ffdf00"/><circle cx="12" cy="8" r="3" fill="#002776"/>';
      case 'AE':
        return '<rect x="6" width="18" height="5.34" fill="#00732f"/><rect x="6" y="5.33" width="18" height="5.34" fill="#ffffff"/><rect x="6" y="10.66" width="18" height="5.34" fill="#000000"/><rect width="6" height="16" fill="#ff0000"/>';
      case 'IL':
        return '<rect width="24" height="16" fill="#ffffff"/><rect y="1.5" width="24" height="2.2" fill="#0038b8"/><rect y="12.3" width="24" height="2.2" fill="#0038b8"/><polygon points="12,4.8 14.8,9.8 9.2,9.8" fill="none" stroke="#0038b8" stroke-width="1"/><polygon points="12,11.2 14.8,6.2 9.2,6.2" fill="none" stroke="#0038b8" stroke-width="1"/>';
      default:
        return '<rect width="24" height="16" fill="#334155"/><circle cx="12" cy="8" r="4.5" fill="none" stroke="#94a3b8" stroke-width="1.2"/><path d="M7.5 8h9M12 3.5v9" stroke="#94a3b8" stroke-width="1"/>';
    }
  }

  function renderFlagBadge(code) {
    const iso = code && /^[A-Z]{2}$/.test(code) ? code : 'UN';
    const label = REGION_NAMES[iso] ? iso + ' · ' + REGION_NAMES[iso] : iso;
    return (
      '<span class="node-flag-wrap" title="' + esc(label) + '">' +
        '<svg class="node-flag-svg" viewBox="0 0 24 16" role="img" aria-label="' + esc(label) + '">' +
          flagSvgInner(iso) +
        '</svg>' +
        '<span class="node-iso">' + esc(iso === 'UN' ? '--' : iso) + '</span>' +
      '</span>'
    );
  }

  /* ─── Formatting & Encoding Utilities ─── */
  function fmtBytes(value) {
    const bytes = Number(value) || 0;
    if (bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return (bytes / Math.pow(1024, index)).toFixed(index >= 3 ? 2 : index ? 1 : 0) + ' ' + units[index];
  }

  function fmtDate(value) {
    if (!value) return '长期有效';
    const date = new Date(value);
    return Number.isNaN(date.getTime())
      ? String(value)
      : date.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' });
  }

  function fmtExpireRemaining(value) {
    if (!value) return '不限到期时间';
    const ts = new Date(value).getTime();
    if (Number.isNaN(ts)) return '—';
    const diffMs = ts - Date.now();
    const days = Math.ceil(diffMs / 86400000);
    if (diffMs < 0) return '已过期 ' + Math.abs(Math.floor(diffMs / 86400000)) + ' 天';
    if (days <= 0) return '今日内到期';
    return '剩余 ' + days + ' 天';
  }

  function statusIndicator(status, expired, quotaExhausted) {
    if (status === 0) return '<span class="status-indicator danger"><i></i>已停用</span>';
    if (expired || status === 2) return '<span class="status-indicator warn"><i></i>已到期</span>';
    if (quotaExhausted || status === 3) return '<span class="status-indicator warn"><i></i>流量超限</span>';
    return '<span class="status-indicator ok"><i></i>正常可用</span>';
  }

  function absSub(value) {
    if (!value) return '';
    return /^https?:\/\//i.test(value) ? value : location.origin + value;
  }

  function targetUrl(base, target) {
    const url = absSub(base);
    if (!url || !target) return url;
    return url + (url.includes('?') ? '&' : '?') + 't=' + encodeURIComponent(target);
  }

  function toBase64Url(str) {
    const bytes = new TextEncoder().encode(str);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    })[character]);
  }

  async function copyText(value) {
    if (!value) throw new Error('订阅地址为空');
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
      return;
    }
    const input = document.createElement('textarea');
    input.value = value;
    input.setAttribute('readonly', '');
    input.style.position = 'fixed';
    input.style.opacity = '0';
    document.body.appendChild(input);
    input.select();
    const copied = document.execCommand('copy');
    input.remove();
    if (!copied) throw new Error('复制失败，请手动选中复制');
  }

  /* ─── 9-Client Import & ?t= Copy Matrix Definition ─── */
  const CLIENT_MATRIX = [
    {
      id: 'clash',
      name: 'Clash Meta (Mihomo)',
      platform: 'Win / macOS / Android',
      target: 'clash',
      scheme: (url, brand) =>
        'clash://install-config?url=' + encodeURIComponent(url) + '&name=' + encodeURIComponent(brand),
    },
    {
      id: 'singbox',
      name: 'Sing-box',
      platform: '全平台核心客户端',
      target: 'singbox',
      scheme: (url, brand) =>
        'sing-box://import-remote-profile?url=' + encodeURIComponent(url) + '#' + encodeURIComponent(brand),
    },
    {
      id: 'shadowrocket',
      name: 'Shadowrocket',
      platform: 'iOS / macOS',
      target: 'shadowrocket',
      scheme: (url, brand) =>
        'shadowrocket://add/sub://' + toBase64Url(url) + '?remark=' + encodeURIComponent(brand),
    },
    {
      id: 'surge',
      name: 'Surge',
      platform: 'iOS / macOS',
      target: 'surge',
      scheme: (url, brand) =>
        'surge:///install-config?url=' + encodeURIComponent(url) + '&name=' + encodeURIComponent(brand),
    },
    {
      id: 'quanx',
      name: 'Quantumult X',
      platform: 'iOS / iPadOS',
      target: 'quanx',
      scheme: (url, brand) =>
        'quantumult-x:///add-resource?remote-resource=' +
        encodeURIComponent(JSON.stringify({ server_remote: [url + ', tag=' + brand] })),
    },
    {
      id: 'loon',
      name: 'Loon',
      platform: 'iOS / macOS',
      target: 'loon',
      scheme: (url) => 'loon://import?sub=' + encodeURIComponent(url),
    },
    {
      id: 'stash',
      name: 'Stash',
      platform: 'iOS / macOS',
      target: 'stash',
      scheme: (url, brand) =>
        'stash://install-config?url=' + encodeURIComponent(url) + '&name=' + encodeURIComponent(brand),
    },
    {
      id: 'surfboard',
      name: 'Surfboard',
      platform: 'Android',
      target: 'surfboard',
      scheme: (url) => 'surfboard:///install-config?url=' + encodeURIComponent(url),
    },
    {
      id: 'hiddify',
      name: 'Hiddify / 通用订阅',
      platform: '自适应全平台',
      target: '',
      scheme: (url, brand) => 'hiddify://import/' + url + '#' + encodeURIComponent(brand),
    },
  ];

  const IMPORT_ARROW_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7"/><path d="M7 7h10v10"/></svg>';
  const COPY_ICON_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>';

  function renderRateBadge(rateVal) {
    const r = Number(rateVal);
    const num = Number.isFinite(r) && r > 0 ? r : 1;
    const cls = num < 1 ? 'node-rate low' : num > 1 ? 'node-rate high' : 'node-rate';
    const text = (Number.isInteger(num) ? num.toFixed(1) : String(num)) + 'x';
    return '<span class="' + cls + '">' + esc(text) + '</span>';
  }

  function renderInternalNode(node) {
    const iso = inferRegionCode(node);
    const cleanName = stripEmojiFlags(node.name) || node.name || '未命名节点';
    const proto = String(node.type || 'PROXY').toUpperCase();
    const online = Boolean(node.online);
    return (
      '<div class="node-item">' +
        renderFlagBadge(iso) +
        '<span class="node-copy">' +
          '<span class="node-name" title="' + esc(cleanName) + '">' + esc(cleanName) + '</span>' +
          '<span class="node-badges">' +
            '<span class="node-proto">' + esc(proto) + '</span>' +
            renderRateBadge(node.rate) +
          '</span>' +
        '</span>' +
        '<span class="node-state ' + (online ? 'online' : '') + '"><i></i>' + (online ? '在线' : '离线') + '</span>' +
      '</div>'
    );
  }

  function renderExternalNode(node) {
    const iso = inferRegionCode(node);
    const cleanName = stripEmojiFlags(node.name) || node.name || '外部节点';
    const proto = String(node.protocol || 'LINK').toUpperCase();
    return (
      '<div class="node-item">' +
        renderFlagBadge(iso) +
        '<span class="node-copy">' +
          '<span class="node-name" title="' + esc(cleanName) + '">' + esc(cleanName) + '</span>' +
          '<span class="node-badges">' +
            '<span class="node-proto">' + esc(proto) + '</span>' +
            (node.rate != null ? renderRateBadge(node.rate) : '') +
          '</span>' +
        '</span>' +
        '<span class="node-state online"><i></i>可用</span>' +
      '</div>'
    );
  }

  function buildDiagnosticEmptyHtml(opts) {
    const { status, expired, expiredAt, quotaExhausted, totalBytes, nextResetText, hasPlan, loadError } = opts;
    let tone = '';
    let title = '暂无可用节点';
    let desc = '当前套餐权限组下暂未分配在线节点，请稍后点击下方按钮刷新重试。';

    if (loadError) {
      tone = 'danger';
      title = '节点列表加载失败';
      desc = loadError;
    } else if (status === 0) {
      tone = 'danger';
      title = '账户已停用，节点暂停下发';
      desc = '当前账户已被停用，系统不会向客户端下发接入节点。如有疑问请联系管理员核实账户状态。';
    } else if (expired || status === 2) {
      tone = 'warn';
      title = '账户有效期已届满，节点暂停下发';
      desc = '账户已于 ' + fmtDate(expiredAt) + ' 到期，当前暂停调度接入节点。';
    } else if (quotaExhausted || status === 3) {
      tone = 'warn';
      title = '周期流量配额已用尽，节点暂停下发';
      desc = '本周期流量上限（' + fmtBytes(totalBytes) + '）已耗尽。预计下次重置：' + nextResetText + '。';
    } else if (!hasPlan) {
      tone = 'warn';
      title = '尚未关联可用套餐';
      desc = '当前账户暂未关联套餐或节点权限组，暂无可调度的接入节点。';
    }

    return (
      '<span class="node-empty-icon ' + tone + '">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>' +
      '</span>' +
      '<h3>' + esc(title) + '</h3>' +
      '<p>' + esc(desc) + '</p>' +
      '<button type="button" class="btn ghost sm" id="nodes-retry-btn">重新加载节点</button>'
    );
  }

  window.mountPortalDashboard = function mountPortalDashboard(context) {
    const {
      query: $,
      rpc,
      toast,
      uiConfirm,
      getToken,
      setToken,
      isSessionActive,
      logout,
      bindThemeButtons,
      profile,
      brandName,
    } = context;

    const setText = (sel, val) => {
      const el = $(sel);
      if (el) el.textContent = val;
    };
    const setHtml = (sel, val) => {
      const el = $(sel);
      if (el) el.innerHTML = val;
    };

    const currentProfile = profile || {};
    const expired =
      Boolean(currentProfile.expired_at) && new Date(currentProfile.expired_at).getTime() < Date.now();
    const used = Number(currentProfile.used_total) || 0;
    const total = Number(currentProfile.transfer_enable) || 0;
    const quotaExhausted = total > 0 && used >= total;
    const statusHtml = statusIndicator(currentProfile.status, expired, quotaExhausted);
    const displayName =
      (currentProfile.name || '').trim() || (currentProfile.email || '').split('@')[0] || '用户';

    const rawUp = currentProfile.u ?? currentProfile.upload ?? currentProfile.used_upload;
    const rawDown = currentProfile.d ?? currentProfile.download ?? currentProfile.used_download;
    const hasSplitTraffic = rawUp != null || rawDown != null;
    const upDownText = hasSplitTraffic
      ? '↑ ' + fmtBytes(Number(rawUp) || 0) + ' · ↓ ' + fmtBytes(Number(rawDown) || 0)
      : used === 0
        ? '↑ 0 B · ↓ 0 B'
        : '↑ / ↓ 累计 ' + fmtBytes(used);

    const speedText = currentProfile.speed_limit ? currentProfile.speed_limit + ' Mbps' : '不限速';
    const deviceText = currentProfile.device_limit ? currentProfile.device_limit + ' 台设备' : '不限设备';

    setText('#a-email', currentProfile.email || '—');
    setText('#a-plan', currentProfile.plan_name || '未分配套餐');
    setText('#a-limits-inline', speedText + ' · ' + deviceText);

    const resetTime = (value) => {
      if (!value) return '尚无记录';
      const d = new Date(value);
      try {
        return d.toLocaleString('zh-CN', {
          hour12: false,
          timeZone: currentProfile.business_timezone || 'Asia/Shanghai',
        });
      } catch (_err) {
        return d.toLocaleString('zh-CN', { hour12: false, timeZone: 'Asia/Shanghai' });
      }
    };

    const nextResetText = currentProfile.next_reset_at
      ? resetTime(currentProfile.next_reset_at)
      : { never: '不自动重置', paused: '已暂停', pending: '等待初始化', no_plan: '无套餐' }[
          currentProfile.reset_schedule_status
        ] || '未安排';

    const resetPolicyLabels = ['每月 1 日', '按周期每月重置', '不自动重置', '每年 1 月 1 日', '按周期每年重置'];
    setText('#t-last-reset', resetTime(currentProfile.last_reset_at));
    setText('#t-next-reset', nextResetText);
    setText(
      '#t-reset-policy',
      (resetPolicyLabels[currentProfile.reset_policy] || '无自动重置策略') +
        ' · ' +
        (currentProfile.business_timezone || 'Asia/Shanghai'),
    );

    setHtml('#a-status', statusHtml);
    setHtml('#heading-status', statusHtml);
    setText(
      '#a-status-sub',
      currentProfile.status === 0
        ? '连接鉴权已暂停'
        : expired || currentProfile.status === 2
          ? '有效期限已届满'
          : quotaExhausted || currentProfile.status === 3
            ? '等待流量重置'
            : '连接鉴权正常',
    );
    setText('#a-expire', fmtDate(currentProfile.expired_at));
    setText('#a-expire-sub', fmtExpireRemaining(currentProfile.expired_at));
    setText('#a-devices', currentProfile.device_limit ? currentProfile.device_limit + ' 台' : '不限制');
    setText('#a-speed', currentProfile.speed_limit ? currentProfile.speed_limit + ' Mbps' : '不限制');
    setText('#chip-speed', '速率上限: ' + (currentProfile.speed_limit ? currentProfile.speed_limit + ' Mbps' : '不限制'));
    setText('#chip-devices', '设备限制: ' + (currentProfile.device_limit ? currentProfile.device_limit + ' 台' : '不限制'));
    setText('#side-name', displayName);
    setText('#side-email', currentProfile.email || '—');
    setText('#account-avatar', displayName.slice(0, 1).toUpperCase());

    /* Linear Quota Progress Bar (<75% emerald, >=75% amber, >=90% rose) */
    const percentage = total > 0 ? Math.min(100, (used / total) * 100) : 0;
    const ratioText = total > 0 ? fmtBytes(used) + ' / ' + fmtBytes(total) : '∞ 无限制';
    const pctText = total > 0 ? percentage.toFixed(1) + '%' : '∞ 无限制';

    setText('#t-ratio', ratioText);
    setText('#t-used', fmtBytes(used));
    setText('#t-total', total > 0 ? fmtBytes(total) : '∞ 无限制');
    setText('#t-left', total > 0 ? fmtBytes(Math.max(0, total - used)) : '∞ 无限制');
    setText('#t-pct', pctText);
    setText('#t-updown', upDownText);
    setText('#t-updown-summary', upDownText);

    const pctEl = $('#t-pct');
    if (pctEl) {
      pctEl.className =
        'quota-pct mono' + (percentage >= 90 ? ' danger' : percentage >= 75 ? ' warn' : '');
    }
    const bar = $('#t-bar');
    if (bar) {
      bar.value = percentage;
      bar.className = percentage >= 90 ? 'bar danger' : percentage >= 75 ? 'bar warn' : 'bar';
    }

    const sUrlInput = $('#s-url');
    if (sUrlInput) sUrlInput.value = absSub(currentProfile.subscribe_url);

    setText('#title-d', brandName);
    setText('#foot', brandName);
    bindThemeButtons();

    /* ─── Offline QR Code Drawer ─── */
    let activeQrFmt = '';
    const qrToggle = $('#s-qr-toggle');
    const qrDrawer = $('#s-qr-drawer');
    const qrBox = $('#s-qr-svg');
    const qrPreview = $('#s-qr-url-preview');

    function updateQrGraphic() {
      if (!qrBox) return;
      const qrTargetLink = activeQrFmt
        ? targetUrl(currentProfile.subscribe_url, activeQrFmt)
        : absSub(currentProfile.subscribe_url);
      qrBox.innerHTML = renderQrSvgMarkup(qrTargetLink);
      if (qrPreview) qrPreview.textContent = qrTargetLink;
    }

    if (qrToggle && qrDrawer) {
      qrToggle.addEventListener('click', () => {
        const nextOpen = qrDrawer.classList.contains('hide');
        qrDrawer.classList.toggle('hide', !nextOpen);
        qrToggle.setAttribute('aria-expanded', String(nextOpen));
        if (nextOpen) updateQrGraphic();
      });
    }

    document.querySelectorAll('[data-qr-fmt]').forEach((btn) => {
      btn.addEventListener('click', () => {
        activeQrFmt = btn.getAttribute('data-qr-fmt') || '';
        document.querySelectorAll('[data-qr-fmt]').forEach((b) => {
          b.classList.toggle('active', b === btn);
        });
        updateQrGraphic();
      });
    });

    /* ─── Render 9-Client Import & Copy Matrix ─── */
    const matrixEl = $('#client-matrix');
    if (matrixEl) {
      matrixEl.innerHTML = CLIENT_MATRIX.map(
        (client) =>
          '<div class="client-card">' +
            '<button type="button" class="client-import-btn" data-client-import="' + esc(client.id) + '" title="一键唤醒导入 ' + esc(client.name) + '">' +
              '<span class="client-name">' + esc(client.name) + '</span>' +
              '<span class="client-sub">' + IMPORT_ARROW_SVG + '<span>一键导入 · ' + esc(client.platform) + '</span></span>' +
            '</button>' +
            '<button type="button" class="client-copy-btn" data-client-copy="' + esc(client.id) + '" aria-label="复制 ' + esc(client.name) + ' 订阅链接" title="复制 ' + esc(client.name) + (client.target ? ' (?t=' + client.target + ')' : ' 通用') + ' 链接">' +
              COPY_ICON_SVG +
            '</button>' +
          '</div>',
      ).join('');

      matrixEl.querySelectorAll('[data-client-import]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-client-import');
          const client = CLIENT_MATRIX.find((c) => c.id === id);
          if (!client) return;
          const subLink = targetUrl(currentProfile.subscribe_url, client.target);
          if (!subLink) {
            toast('订阅地址为空', 'error');
            return;
          }
          const brand = brandName || document.title || 'Sub';
          location.href = client.scheme(subLink, brand);
          setTimeout(() => toast('已发起唤醒，若未反应请确认已安装 ' + client.name), 600);
        });
      });

      matrixEl.querySelectorAll('[data-client-copy]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const id = btn.getAttribute('data-client-copy');
          const client = CLIENT_MATRIX.find((c) => c.id === id);
          if (!client) return;
          const subLink = targetUrl(currentProfile.subscribe_url, client.target);
          try {
            await copyText(subLink);
            toast('已复制 ' + client.name + ' 订阅链接', 'success');
          } catch (error) {
            toast(error.message || '复制失败', 'error');
          }
        });
      });
    }

    /* ─── Account Security Modal ─── */
    const accountTrigger = $('#account-trigger');
    const securityModal = $('#security-modal');
    const securityClose = $('#security-close');
    const setSecurityModal = (open) => {
      if (!securityModal || !accountTrigger) return;
      securityModal.classList.toggle('hide', !open);
      securityModal.setAttribute('aria-hidden', String(!open));
      accountTrigger.setAttribute('aria-expanded', String(open));
      document.body.classList.toggle('modal-open', open);
      if (open && securityClose) {
        securityClose.focus();
      } else if (!open && document.contains(accountTrigger)) {
        accountTrigger.focus();
      }
    };

    if (accountTrigger && securityModal && securityClose) {
      accountTrigger.addEventListener('click', () => setSecurityModal(true));
      securityClose.addEventListener('click', () => setSecurityModal(false));
      securityModal.addEventListener('click', (event) => {
        if (event.target === securityModal) setSecurityModal(false);
      });
      securityModal.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          setSecurityModal(false);
          return;
        }
        if (event.key !== 'Tab') return;
        const focusable = [
          ...securityModal.querySelectorAll('button:not([disabled]), input:not([disabled])'),
        ];
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      });
    }

    /* ─── Fetch & Render Nodes (Always Visible with Diagnostic Empty State) ─── */
    const nodesSection = $('#nodes');
    const nodesEmpty = $('#nodes-empty');
    const internalGroup = $('#internal-group');
    const externalGroup = $('#external-group');
    const initialToken = typeof getToken === 'function' ? getToken() : null;

    function checkActive() {
      if (typeof isSessionActive === 'function' && !isSessionActive()) return false;
      if (!isSessionActive && initialToken && typeof getToken === 'function' && getToken() !== initialToken) {
        return false;
      }
      return Boolean(nodesSection && document.contains(nodesSection));
    }

    function showNodesEmptyState(loadError) {
      if (!nodesSection) return;
      nodesSection.classList.remove('hide');
      if (internalGroup) internalGroup.classList.add('hide');
      if (externalGroup) externalGroup.classList.add('hide');
      setText('#n-count', '0');
      setText('#n-online', '0');
      if (nodesEmpty) {
        nodesEmpty.classList.remove('hide');
        nodesEmpty.innerHTML = buildDiagnosticEmptyHtml({
          status: currentProfile.status,
          expired,
          expiredAt: currentProfile.expired_at,
          quotaExhausted,
          totalBytes: total,
          nextResetText,
          hasPlan: Boolean(currentProfile.plan_name),
          loadError,
        });
        const retryBtn = $('#nodes-retry-btn');
        if (retryBtn) {
          retryBtn.addEventListener('click', () => loadNodes());
        }
      }
    }

    function loadNodes() {
      rpc('user.nodes', {})
        .then((data) => {
          if (!checkActive()) return;
          nodesSection.classList.remove('hide');
          const nodes = (data && data.nodes) || [];
          const external = (data && data.external) || [];

          if (!nodes.length && !external.length) {
            showNodesEmptyState(null);
            return;
          }

          if (nodesEmpty) nodesEmpty.classList.add('hide');
          const onlineInternal = nodes.filter((node) => node.online).length;
          setText('#n-count', String(nodes.length + external.length));
          setText('#n-online', String(onlineInternal + external.length));

          if (nodes.length && internalGroup) {
            internalGroup.classList.remove('hide');
            setText('#n-internal-count', String(nodes.length));
            setHtml('#n-list', nodes.map(renderInternalNode).join(''));
          } else if (internalGroup) {
            internalGroup.classList.add('hide');
          }

          if (external.length && externalGroup) {
            externalGroup.classList.remove('hide');
            setText('#n-external-count', String(external.length));
            setHtml('#n-external-list', external.map(renderExternalNode).join(''));
          } else if (externalGroup) {
            externalGroup.classList.add('hide');
          }
        })
        .catch((err) => {
          if (!checkActive()) return;
          showNodesEmptyState((err && err.message) || '无法获取节点列表，请检查网络连接后重试。');
        });
    }

    loadNodes();

    /* ─── Primary Actions: Logout, Copy, Reset Token, Change Password ─── */
    const logoutBtn = $('#logout');
    if (logoutBtn) logoutBtn.addEventListener('click', logout);

    const copyBtn = $('#s-copy');
    if (copyBtn) {
      copyBtn.addEventListener('click', async () => {
        try {
          await copyText(sUrlInput ? sUrlInput.value : absSub(currentProfile.subscribe_url));
          toast('通用订阅链接已复制', 'success');
        } catch (error) {
          toast(error.message || '复制失败', 'error');
        }
      });
    }

    const resetBtn = $('#s-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', async () => {
        const confirmed = await uiConfirm({
          title: '确认重置订阅链接',
          description: '重置后当前订阅地址与二维码将立即作废，您需要在所有已配置的客户端中重新导入新地址。',
          confirmText: '确认重置',
          danger: true,
        });
        if (!confirmed) return;
        try {
          const data = await rpc('user.reset_sub_token', {});
          currentProfile.subscribe_url = data.subscribe_url;
          if (sUrlInput) sUrlInput.value = absSub(data.subscribe_url);
          if (qrDrawer && !qrDrawer.classList.contains('hide')) {
            updateQrGraphic();
          }
          toast('订阅密钥已重置，请重新导入客户端', 'success');
        } catch (error) {
          toast(error.message || '重置失败', 'error');
        }
      });
    }

    const pwForm = $('#pwForm');
    if (pwForm) {
      pwForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const button = $('#pw-btn');
        const oldLabel = button.textContent;
        button.disabled = true;
        button.innerHTML = '<span class="spin"></span>';
        try {
          const res = await rpc('user.change_password', {
            old_password: $('#pw-old').value,
            new_password: $('#pw-new').value,
          });
          $('#pw-old').value = '';
          $('#pw-new').value = '';
          const saveTok = typeof setToken === 'function' ? setToken : null;
          if (res && res.token && saveTok) {
            saveTok(res.token);
            setSecurityModal(false);
            toast('登录密码已更新', 'success');
          } else {
            setSecurityModal(false);
            logout();
            toast('密码已更新，请使用新密码重新登录', 'success');
          }
        } catch (error) {
          toast(error.message || '密码更新失败', 'error');
        } finally {
          button.disabled = false;
          button.textContent = oldLabel;
        }
      });
    }
  };
})();
