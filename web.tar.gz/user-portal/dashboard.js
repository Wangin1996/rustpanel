'use strict';

(function registerDashboard() {
  function fmtBytes(value) {
    const bytes = Number(value) || 0;
    if (bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const index = Math.min(
      Math.floor(Math.log(bytes) / Math.log(1024)),
      units.length - 1,
    );
    return (bytes / Math.pow(1024, index)).toFixed(index ? 2 : 0) + ' ' + units[index];
  }

  function fmtDate(value) {
    if (!value) return '长期有效';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('zh-CN');
  }

  function statusPill(status, expired) {
    if (status === 0) return '<span class="pill danger">已停用</span>';
    if (expired) return '<span class="pill warn">已到期</span>';
    return '<span class="pill ok">正常</span>';
  }

  function absSub(value) {
    if (!value) return '';
    return /^https?:\/\//i.test(value) ? value : location.origin + value;
  }

  function targetUrl(base, target) {
    const url = absSub(base);
    return url + (url.includes('?') ? '&' : '?') + 't=' + target;
  }

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    })[character]);
  }

  const NODE_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/></svg>';
  const LINK_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>';

  window.mountPortalDashboard = function mountPortalDashboard(context) {
    const {
      query: $,
      rpc,
      toast,
      uiConfirm,
      clearToken,
      showLogin,
      profile,
      brandName,
    } = context;

    rpc('user.nodes', {}).then((data) => {
      const nodes = (data && data.nodes) || [];
      const external = (data && data.external) || [];
      if (!nodes.length && !external.length) return;
      $('#nodes-card').classList.remove('hide');
      $('#n-count').textContent = '· ' + (nodes.length + external.length) + ' 个';
      let html = '';
      nodes.forEach((node) => {
        const subtitle = esc(node.type) + (
          node.rate && Number(node.rate) !== 1 ? ' · ' + Number(node.rate) + 'x' : ''
        );
        html += '<div class="nitem">' +
          '<span class="nic">' + NODE_ICON + '<i class="ndot ' + (node.online ? 'on' : 'off') + '"></i></span>' +
          '<span class="nmeta"><span class="nname">' + esc(node.name) + '</span><span class="nsub">' + subtitle + '</span></span>' +
          '<span class="nstat ' + (node.online ? 'on' : 'off') + '">' + (node.online ? '在线' : '离线') + '</span></div>';
      });
      external.forEach((node) => {
        html += '<div class="nitem">' +
          '<span class="nic ext">' + LINK_ICON + '</span>' +
          '<span class="nmeta"><span class="nname">' + esc(node.name) + '</span><span class="nsub">' + esc(node.protocol || 'link') + '</span></span>' +
          '<span class="nstat off">外部</span></div>';
      });
      $('#n-list').innerHTML = html;
    }).catch(() => {});

    const currentProfile = profile || {};
    const expired = currentProfile.expired_at && (
      new Date(currentProfile.expired_at).getTime() < Date.now()
    );
    $('#a-email').textContent = currentProfile.email || '—';
    $('#a-plan').textContent = currentProfile.plan_name || '（无套餐）';
    $('#a-status').innerHTML = statusPill(currentProfile.status, expired);
    $('#a-expire').textContent = fmtDate(currentProfile.expired_at);

    const used = Number(currentProfile.used_total) || 0;
    const total = Number(currentProfile.transfer_enable) || 0;
    const percentage = total > 0 ? Math.min(100, used / total * 100) : 0;
    $('#t-used').textContent = fmtBytes(used);
    $('#t-total').textContent = total > 0 ? fmtBytes(total) : '∞';
    $('#t-left').textContent = total > 0 ? fmtBytes(Math.max(0, total - used)) : '∞';
    $('#t-pct').textContent = total > 0 ? percentage.toFixed(0) + '%' : '不限量';
    const bar = $('#t-bar');
    bar.value = percentage;
    bar.className = percentage >= 90 ? 'bar danger' : percentage >= 70 ? 'bar warn' : 'bar';
    $('#s-url').value = absSub(currentProfile.subscribe_url);

    const dashboardTitle = $('#title-d');
    if (dashboardTitle) dashboardTitle.textContent = brandName;
    const footer = $('#foot');
    if (footer) footer.textContent = brandName;

    $('#logout').addEventListener('click', () => {
      clearToken();
      showLogin();
    });
    $('#s-copy').addEventListener('click', async () => {
      await navigator.clipboard?.writeText($('#s-url').value);
      toast('订阅链接已复制', 'success');
    });
    $('#s-copy-clash').addEventListener('click', async () => {
      await navigator.clipboard?.writeText(targetUrl(currentProfile.subscribe_url, 'clash'));
      toast('Clash 链接已复制', 'success');
    });
    document.querySelectorAll('[data-import]').forEach((button) => {
      button.addEventListener('click', () => {
        const target = button.getAttribute('data-import');
        const encodedUrl = encodeURIComponent(targetUrl(currentProfile.subscribe_url, target));
        const scheme = target === 'clash'
          ? 'clash://install-config?url=' + encodedUrl + '&name=' + encodeURIComponent(document.title)
          : 'sing-box://import-remote-profile?url=' + encodedUrl;
        location.href = scheme;
        setTimeout(() => toast('若未跳转，请确认已安装对应客户端'), 600);
      });
    });
    $('#s-reset').addEventListener('click', async () => {
      const confirmed = await uiConfirm({
        title: '重置订阅链接',
        description: '重置后旧链接会立即失效，需要在客户端里重新导入新链接。',
        confirmText: '确认重置',
        danger: true,
      });
      if (!confirmed) return;
      try {
        const data = await rpc('user.reset_sub_token', {});
        currentProfile.subscribe_url = data.subscribe_url;
        $('#s-url').value = absSub(data.subscribe_url);
        toast('已重置，请重新导入', 'success');
      } catch (error) {
        toast(error.message, 'error');
      }
    });
    $('#pwForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#pw-btn');
      button.disabled = true;
      try {
        await rpc('user.change_password', {
          old_password: $('#pw-old').value,
          new_password: $('#pw-new').value,
        });
        $('#pw-old').value = '';
        $('#pw-new').value = '';
        toast('密码已更新', 'success');
      } catch (error) {
        toast(error.message || '更新失败', 'error');
      } finally {
        button.disabled = false;
      }
    });
  };
})();
