'use strict';

(function registerDashboard() {
  function fmtBytes(value) {
    const bytes = Number(value) || 0;
    if (bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const index = Math.min(
      Math.floor(Math.log(bytes) / Math.log(1024)),
      units.length - 1,
    );
    return (bytes / Math.pow(1024, index)).toFixed(index ? 2 : 0) + ' ' + units[index];
  }

  function fmtDate(value) {
    if (!value) return '长期有效';
    const date = new Date(value);
    return Number.isNaN(date.getTime())
      ? String(value)
      : date.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' });
  }

  function statusIndicator(status, expired) {
    if (status === 0) return '<span class="status-indicator danger"><i></i>已停用</span>';
    if (expired) return '<span class="status-indicator warn"><i></i>已到期</span>';
    return '<span class="status-indicator ok"><i></i>正常</span>';
  }

  function absSub(value) {
    if (!value) return '';
    return /^https?:\/\//i.test(value) ? value : location.origin + value;
  }

  function targetUrl(base, target) {
    const url = absSub(base);
    return url + (url.includes('?') ? '&' : '?') + 't=' + target;
  }

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    })[character]);
  }

  async function copyText(value) {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
      return;
    }
    const input = document.createElement('textarea');
    input.value = value;
    input.setAttribute('readonly', '');
    input.style.position = 'fixed';
    input.style.opacity = '0';
    document.body.appendChild(input);
    input.select();
    const copied = document.execCommand('copy');
    input.remove();
    if (!copied) throw new Error('复制失败，请手动复制');
  }

  const NODE_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="20" height="8" x="2" y="2" rx="2"/><rect width="20" height="8" x="2" y="14" rx="2"/><path d="M6 6h.01M6 18h.01"/></svg>';
  const LINK_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>';

  function internalNode(node) {
    const subtitle = esc(node.type) + (
      node.rate && Number(node.rate) !== 1 ? ' · ' + Number(node.rate) + 'x' : ''
    );
    const online = Boolean(node.online);
    return '<div class="node-item">' +
      '<span class="node-icon">' + NODE_ICON + '<i class="node-dot ' + (online ? 'online' : '') + '"></i></span>' +
      '<span class="node-copy"><span class="node-name">' + esc(node.name) + '</span><span class="node-meta">' + subtitle + '</span></span>' +
      '<span class="node-state ' + (online ? 'online' : '') + '">' + (online ? '在线' : '离线') + '</span>' +
    '</div>';
  }

  function externalNode(node) {
    return '<div class="node-item">' +
      '<span class="node-icon">' + LINK_ICON + '</span>' +
      '<span class="node-copy"><span class="node-name">' + esc(node.name) + '</span><span class="node-meta">' + esc(node.protocol || 'link') + '</span></span>' +
      '<span class="node-state">外部</span>' +
    '</div>';
  }

  window.mountPortalDashboard = function mountPortalDashboard(context) {
    const {
      query: $,
      rpc,
      toast,
      uiConfirm,
      logout,
      bindThemeButtons,
      profile,
      brandName,
    } = context;

    const currentProfile = profile || {};
    const expired = Boolean(currentProfile.expired_at) && (
      new Date(currentProfile.expired_at).getTime() < Date.now()
    );
    const statusHtml = statusIndicator(currentProfile.status, expired);
    const displayName = (currentProfile.name || '').trim() || (currentProfile.email || '').split('@')[0] || '用户';

    $('#a-email').textContent = currentProfile.email || '—';
    $('#a-plan').textContent = currentProfile.plan_name || '无套餐';
    $('#a-status').innerHTML = statusHtml;
    $('#heading-status').innerHTML = statusHtml;
    $('#a-expire').textContent = fmtDate(currentProfile.expired_at);
    $('#a-devices').textContent = currentProfile.device_limit ? currentProfile.device_limit + ' 台' : '不限制';
    $('#a-speed').textContent = currentProfile.speed_limit ? currentProfile.speed_limit + ' Mbps' : '不限制';
    $('#side-name').textContent = displayName;
    $('#side-email').textContent = currentProfile.email || '—';
    $('#account-avatar').textContent = displayName.slice(0, 1).toUpperCase();

    const used = Number(currentProfile.used_total) || 0;
    const total = Number(currentProfile.transfer_enable) || 0;
    const percentage = total > 0 ? Math.min(100, used / total * 100) : 0;
    $('#t-used').textContent = fmtBytes(used);
    $('#t-total').textContent = total > 0 ? fmtBytes(total) : '不限量';
    $('#t-left').textContent = total > 0 ? fmtBytes(Math.max(0, total - used)) : '不限量';
    $('#t-pct').textContent = total > 0 ? percentage.toFixed(0) + '%' : '不限量';
    const bar = $('#t-bar');
    bar.value = percentage;
    bar.className = percentage >= 90 ? 'bar danger' : percentage >= 70 ? 'bar warn' : 'bar';
    $('#s-url').value = absSub(currentProfile.subscribe_url);

    $('#title-d').textContent = brandName;
    $('#foot').textContent = brandName;
    bindThemeButtons();

    rpc('user.nodes', {}).then((data) => {
      const nodes = (data && data.nodes) || [];
      const external = (data && data.external) || [];
      if (!nodes.length && !external.length) return;
      $('#nodes').classList.remove('hide');
      $('#n-count').textContent = nodes.length + external.length;
      $('#n-online').textContent = nodes.filter((node) => node.online).length;

      if (nodes.length) {
        $('#internal-group').classList.remove('hide');
        $('#n-internal-count').textContent = nodes.length;
        $('#n-list').innerHTML = nodes.map(internalNode).join('');
      }
      if (external.length) {
        $('#external-group').classList.remove('hide');
        $('#n-external-count').textContent = external.length;
        $('#n-external-list').innerHTML = external.map(externalNode).join('');
      }
    }).catch(() => {});

    $('#logout').addEventListener('click', logout);
    $('#s-copy').addEventListener('click', async () => {
      try {
        await copyText($('#s-url').value);
        toast('订阅链接已复制', 'success');
      } catch (error) {
        toast(error.message || '复制失败', 'error');
      }
    });
    $('#s-copy-clash').addEventListener('click', async () => {
      try {
        await copyText(targetUrl(currentProfile.subscribe_url, 'clash'));
        toast('Clash 链接已复制', 'success');
      } catch (error) {
        toast(error.message || '复制失败', 'error');
      }
    });
    document.querySelectorAll('[data-import]').forEach((button) => {
      button.addEventListener('click', () => {
        const target = button.getAttribute('data-import');
        const encodedUrl = encodeURIComponent(targetUrl(currentProfile.subscribe_url, target));
        const scheme = target === 'clash'
          ? 'clash://install-config?url=' + encodedUrl + '&name=' + encodeURIComponent(document.title)
          : 'sing-box://import-remote-profile?url=' + encodedUrl;
        location.href = scheme;
        setTimeout(() => toast('若未跳转，请确认已安装对应客户端'), 600);
      });
    });
    $('#s-reset').addEventListener('click', async () => {
      const confirmed = await uiConfirm({
        title: '重置订阅链接',
        description: '重置后旧链接会立即失效，需要在客户端里重新导入新链接。',
        confirmText: '确认重置',
        danger: true,
      });
      if (!confirmed) return;
      try {
        const data = await rpc('user.reset_sub_token', {});
        currentProfile.subscribe_url = data.subscribe_url;
        $('#s-url').value = absSub(data.subscribe_url);
        toast('已重置，请重新导入', 'success');
      } catch (error) {
        toast(error.message, 'error');
      }
    });
    $('#pwForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#pw-btn');
      const oldLabel = button.textContent;
      button.disabled = true;
      button.innerHTML = '<span class="spin"></span>';
      try {
        await rpc('user.change_password', {
          old_password: $('#pw-old').value,
          new_password: $('#pw-new').value,
        });
        $('#pw-old').value = '';
        $('#pw-new').value = '';
        toast('密码已更新', 'success');
      } catch (error) {
        toast(error.message || '更新失败', 'error');
      } finally {
        button.disabled = false;
        button.textContent = oldLabel;
      }
    });
  };
})();
