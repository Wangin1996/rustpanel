'use strict';

const GW = '/api/v1/gateway';
const TKEY = 'up_token';
const $ = (selector) => document.querySelector(selector);
let PROFILE = null;
let BRAND_NAME = '用户中心';
let dashMounted = false;
let toastTimer = null;

function toast(message, type) {
  const element = $('#toast');
  element.textContent = message;
  element.className = type || '';
  void element.offsetWidth;
  element.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove('show'), 2200);
}

function uuid() {
  return crypto.randomUUID
    ? crypto.randomUUID().replace(/-/g, '')
    : String(Math.random()).slice(2) + Date.now();
}

function tok() { return localStorage.getItem(TKEY); }
function setTok(token) { localStorage.setItem(TKEY, token); }
function clearTok() { localStorage.removeItem(TKEY); }

function uiConfirm(options) {
  return new Promise((resolve) => {
    const mask = document.createElement('div');
    mask.className = 'mask';
    mask.innerHTML =
      '<div class="dlg" role="dialog" aria-modal="true">' +
        '<h3><span class="warn-ic"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg></span><span class="dlg-title"></span></h3>' +
        '<p></p>' +
        '<div class="acts"><button class="btn ghost sm" data-x="0">取消</button>' +
        '<button class="btn sm" data-x="1"></button></div>' +
      '</div>';

    mask.querySelector('.dlg-title').textContent = options.title || '确认操作';
    mask.querySelector('p').textContent = options.description || '';
    mask.querySelector('p').classList.toggle('hide', !options.description);
    mask.querySelector('.warn-ic').classList.toggle('hide', !options.danger);
    const confirmButton = mask.querySelector('[data-x="1"]');
    confirmButton.textContent = options.confirmText || '确认';
    confirmButton.classList.toggle('danger', Boolean(options.danger));

    function done(ok) {
      mask.remove();
      document.removeEventListener('keydown', onKey);
      resolve(ok);
    }
    function onKey(event) {
      if (event.key === 'Escape') done(false);
    }

    mask.addEventListener('click', (event) => {
      if (event.target === mask) done(false);
    });
    mask.querySelector('[data-x="0"]').addEventListener('click', () => done(false));
    confirmButton.addEventListener('click', () => done(true));
    document.addEventListener('keydown', onKey);
    document.body.appendChild(mask);
  });
}

async function rpc(method, payload, scope = 'user') {
  const body = {
    version: '1',
    scope,
    method,
    request_id: uuid(),
    timestamp: Math.floor(Date.now() / 1000),
    nonce: uuid(),
    payload: payload || {},
  };
  const headers = { 'content-type': 'application/json' };
  const token = tok();
  if (token && scope === 'user') headers.authorization = 'Bearer ' + token;
  const response = await fetch(GW, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });
  const data = await response.json();
  if (data.code === 401 || data.code === 403) {
    clearTok();
    showLogin();
    throw new Error(data.message || '登录已失效');
  }
  if (data.code !== 0) throw new Error(data.message || '操作失败');
  return data.data;
}

function applyThemeColor(color) {
  if (!/^#[0-9a-fA-F]{6}$/.test(color)) return;
  const sheet = document.getElementById('portal-styles')?.sheet;
  if (!sheet) return;
  try {
    sheet.insertRule(`:root { --primary: ${color}; }`, sheet.cssRules.length);
  } catch (_) {
    // Branding remains usable with the default color if CSSOM is unavailable.
  }
}

async function applyBranding() {
  try {
    const branding = await rpc('admin.branding', {}, 'admin');
    BRAND_NAME = (branding.app_name || '').trim() || '用户中心';
    document.title = BRAND_NAME;
    const loginTitle = $('#title-l');
    if (loginTitle) loginTitle.textContent = BRAND_NAME;
    if (branding.theme_color) applyThemeColor(branding.theme_color);
  } catch (_) {
    // Default branding remains in place when the public branding request fails.
  }
}

async function mountDash() {
  if (dashMounted) return;
  const { html } = await rpc('user.portal_view', {});
  $('#dash').innerHTML = html;
  if (typeof window.mountPortalDashboard !== 'function') {
    throw new Error('用户门户资源加载失败');
  }
  window.mountPortalDashboard({
    query: $,
    rpc,
    toast,
    uiConfirm,
    clearToken: clearTok,
    showLogin,
    profile: PROFILE,
    brandName: BRAND_NAME,
  });
  dashMounted = true;
}

function showLogin() {
  $('#dash').classList.add('hide');
  $('#login').classList.remove('hide');
}

function showDash() {
  $('#login').classList.add('hide');
  $('#dash').classList.remove('hide');
}

async function loadProfile() {
  PROFILE = await rpc('user.profile', {});
  await mountDash();
  showDash();
}

$('#loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = $('#li-btn');
  const oldLabel = button.textContent;
  button.disabled = true;
  button.innerHTML = '<span class="spin"></span>';
  try {
    const data = await rpc('user.auth.login', {
      email: $('#li-email').value.trim(),
      password: $('#li-pass').value,
    }, 'user');
    setTok(data.token);
    await loadProfile();
  } catch (error) {
    toast(error.message || '登录失败', 'error');
  } finally {
    button.disabled = false;
    button.textContent = oldLabel;
  }
});

(async function boot() {
  await applyBranding();
  if (tok()) {
    try {
      await loadProfile();
    } catch (_) {
      showLogin();
    }
  } else {
    showLogin();
  }
})();
