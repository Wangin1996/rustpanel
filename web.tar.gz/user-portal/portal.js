'use strict';

const GW = '/api/v1/gateway';
const TKEY = 'up_token';
const THEME_KEY = 'up_theme';
const $ = (selector) => document.querySelector(selector);
let PROFILE = null;
let BRAND_NAME = '用户中心';
let dashMounted = false;
let sessionEpoch = 0;
let toastTimer = null;

function preferredTheme() {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch (_) {
    // Ignore storage access errors in restricted webviews
  }
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function updateThemeButtons(theme) {
  document.querySelectorAll('[id^="theme-toggle-"]').forEach((button) => {
    const next = theme === 'dark' ? '浅色' : '深色';
    button.setAttribute('aria-label', '切换为' + next + '主题');
    button.setAttribute('title', '切换为' + next + '主题');
  });
}

function applyTheme(theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark');
  const themeMeta = document.querySelector('meta[name="theme-color"]');
  if (themeMeta) themeMeta.content = theme === 'dark' ? '#09090b' : '#fafafa';
  updateThemeButtons(theme);
}

function toggleTheme() {
  const theme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (_) {
    // Ignore storage write errors
  }
  applyTheme(theme);
}

function bindThemeButtons() {
  document.querySelectorAll('[id^="theme-toggle-"]').forEach((button) => {
    if (button.dataset.bound === 'true') return;
    button.dataset.bound = 'true';
    button.addEventListener('click', toggleTheme);
  });
  updateThemeButtons(document.documentElement.classList.contains('dark') ? 'dark' : 'light');
}

applyTheme(preferredTheme());

if (window.matchMedia) {
  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  const onSystemThemeChange = (event) => {
    let saved = null;
    try {
      saved = localStorage.getItem(THEME_KEY);
    } catch (_) {}
    if (saved !== 'light' && saved !== 'dark') {
      applyTheme(event.matches ? 'dark' : 'light');
    }
  };
  if (typeof mq.addEventListener === 'function') {
    mq.addEventListener('change', onSystemThemeChange);
  }
}

function toast(message, type) {
  const element = $('#toast');
  if (!element) return;
  element.textContent = message;
  element.className = type || '';
  void element.offsetWidth;
  element.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove('show'), 2200);
}

function uuid() {
  if (globalThis.crypto && globalThis.crypto.randomUUID) {
    return globalThis.crypto.randomUUID().replace(/-/g, '');
  }
  if (!globalThis.crypto || !globalThis.crypto.getRandomValues) {
    throw new Error('secure random source unavailable');
  }
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  return Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
}

function tok() {
  return localStorage.getItem(TKEY) || sessionStorage.getItem(TKEY);
}
function setTok(token) {
  localStorage.setItem(TKEY, token);
  sessionStorage.removeItem(TKEY);
}
function clearTok() {
  localStorage.removeItem(TKEY);
  sessionStorage.removeItem(TKEY);
}

function logout() {
  sessionEpoch += 1;
  clearTok();
  PROFILE = null;
  dashMounted = false;
  document.body.classList.remove('modal-open');
  $('#dash').replaceChildren();
  const passInput = $('#li-pass');
  if (passInput) passInput.value = '';
  showLogin();
}

function uiConfirm(options) {
  return new Promise((resolve) => {
    const mask = document.createElement('div');
    mask.className = 'mask';
    mask.innerHTML =
      '<div class="dlg" role="dialog" aria-modal="true">' +
        '<h3><span class="warn-ic"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg></span><span class="dlg-title"></span></h3>' +
        '<p></p>' +
        '<div class="acts"><button class="btn ghost sm" type="button" data-x="0">取消</button>' +
        '<button class="btn sm" type="button" data-x="1"></button></div>' +
      '</div>';

    mask.querySelector('.dlg-title').textContent = options.title || '确认操作';
    mask.querySelector('p').textContent = options.description || '';
    mask.querySelector('p').classList.toggle('hide', !options.description);
    mask.querySelector('.warn-ic').classList.toggle('hide', !options.danger);
    const confirmButton = mask.querySelector('[data-x="1"]');
    confirmButton.textContent = options.confirmText || '确认';
    confirmButton.classList.toggle('danger', Boolean(options.danger));

    function done(ok) {
      mask.remove();
      document.removeEventListener('keydown', onKey);
      resolve(ok);
    }
    function onKey(event) {
      if (event.key === 'Escape') done(false);
    }

    mask.addEventListener('click', (event) => {
      if (event.target === mask) done(false);
    });
    mask.querySelector('[data-x="0"]').addEventListener('click', () => done(false));
    confirmButton.addEventListener('click', () => done(true));
    document.addEventListener('keydown', onKey);
    document.body.appendChild(mask);
    confirmButton.focus();
  });
}

const OPEN_PORTAL_METHODS = new Set(['admin.branding', 'user.auth.login']);

async function rpc(method, payload, scope = 'user') {
  const token = tok();
  if (!OPEN_PORTAL_METHODS.has(method) && !token) {
    logout();
    throw new Error('登录已失效');
  }
  const body = {
    version: '1',
    scope,
    method,
    request_id: uuid(),
    timestamp: Math.floor(Date.now() / 1000),
    nonce: uuid(),
    payload: payload || {},
  };
  const headers = { 'content-type': 'application/json' };
  if (token && scope === 'user') headers.authorization = 'Bearer ' + token;
  const response = await fetch(GW, {
    method: 'POST',
    signal: AbortSignal.timeout(30000),
    headers,
    body: JSON.stringify(body),
  });
  if (response.status === 429) {
    throw new Error('请求过于频繁，请稍后再试');
  }
  const rawText = await response.text();
  let data = null;
  if (rawText) {
    try {
      data = JSON.parse(rawText);
    } catch (_err) {
      if (response.status === 401) {
        logout();
        throw new Error('登录已失效');
      }
      if (response.status === 413) {
        throw new Error('请求内容过大');
      }
      if (response.status >= 500) {
        throw new Error('服务暂时不可用，请稍后重试 (' + response.status + ')');
      }
      throw new Error('请求失败 (' + response.status + ')');
    }
  }
  if (!data || typeof data !== 'object') {
    if (response.status === 401) {
      logout();
      throw new Error('登录已失效');
    }
    throw new Error(response.ok ? '服务响应格式异常' : '请求失败 (' + response.status + ')');
  }
  if (response.status === 401 || data.code === 401) {
    logout();
    throw new Error(data.message || '登录已失效');
  }
  if (!response.ok || data.code !== 0) {
    throw new Error(data.message || ('操作失败' + (!response.ok ? ' (' + response.status + ')' : '')));
  }
  return data.data;
}

function normalizeHexColor(color) {
  if (typeof color !== 'string') return null;
  const raw = color.trim().replace(/^#/, '');
  if (/^[0-9a-fA-F]{3}$/.test(raw) || /^[0-9a-fA-F]{4}$/.test(raw)) {
    return '#' + raw.slice(0, 3).split('').map((ch) => ch + ch).join('').toLowerCase();
  }
  if (/^[0-9a-fA-F]{6}$/.test(raw) || /^[0-9a-fA-F]{8}$/.test(raw)) {
    return '#' + raw.slice(0, 6).toLowerCase();
  }
  return null;
}

function applyThemeColor(color) {
  const hex = normalizeHexColor(color);
  if (!hex) return;
  const red = parseInt(hex.slice(1, 3), 16);
  const green = parseInt(hex.slice(3, 5), 16);
  const blue = parseInt(hex.slice(5, 7), 16);
  const luminance = (0.299 * red + 0.587 * green + 0.114 * blue) / 255;
  document.documentElement.style.setProperty('--primary', hex);
  document.documentElement.style.setProperty('--brand', hex);
  document.documentElement.style.setProperty(
    '--primary-foreground',
    luminance > 0.62 ? '#09090b' : '#ffffff',
  );
}

async function applyBranding() {
  try {
    const branding = await rpc('admin.branding', {}, 'admin');
    BRAND_NAME = (branding.app_name || '').trim() || '用户中心';
    document.title = BRAND_NAME;
    const loginTitle = $('#title-l');
    if (loginTitle) loginTitle.textContent = BRAND_NAME;
    if (branding.theme_color) applyThemeColor(branding.theme_color);
  } catch (_) {
    // Default branding remains in place when the public branding request fails.
  }
}

async function mountDash() {
  if (dashMounted) return;
  const mountedEpoch = sessionEpoch;
  const { html } = await rpc('user.portal_view', {});
  if (mountedEpoch !== sessionEpoch || !tok()) return;
  $('#dash').innerHTML = html;
  if (typeof window.mountPortalDashboard !== 'function') {
    throw new Error('用户门户资源加载失败');
  }
  window.mountPortalDashboard({
    query: $,
    rpc,
    toast,
    uiConfirm,
    getToken: tok,
    setToken: setTok,
    clearToken: clearTok,
    isSessionActive: () => sessionEpoch === mountedEpoch && Boolean(tok()),
    logout,
    showLogin,
    bindThemeButtons,
    profile: PROFILE,
    brandName: BRAND_NAME,
  });
  dashMounted = true;
}

function showLogin() {
  $('#dash').classList.add('hide');
  $('#login').classList.remove('hide');
  bindThemeButtons();
}

function showDash() {
  $('#login').classList.add('hide');
  $('#dash').classList.remove('hide');
  bindThemeButtons();
}

async function loadProfile() {
  PROFILE = await rpc('user.profile', {});
  await mountDash();
  showDash();
}

$('#loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = $('#li-btn');
  const oldLabel = button.textContent;
  button.disabled = true;
  button.innerHTML = '<span class="spin"></span>';
  try {
    const data = await rpc('user.auth.login', {
      email: $('#li-email').value.trim(),
      password: $('#li-pass').value,
    }, 'user');
    setTok(data.token);
    await loadProfile();
  } catch (error) {
    toast(error.message || '登录失败', 'error');
  } finally {
    button.disabled = false;
    button.textContent = oldLabel;
  }
});

(async function boot() {
  await applyBranding();
  if (tok()) {
    try {
      await loadProfile();
    } catch (_) {
      showLogin();
    }
  } else {
    showLogin();
  }
})();
