window.settings = { base_url: '/', title: 'rust-panel admin', version: 'dev', logo: '', secure_path: 'gw' };
