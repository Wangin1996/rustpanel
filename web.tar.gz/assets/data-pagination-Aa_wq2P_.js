import{j as e}from"./query-BAGFhzbn.js";import{c as n,B as i}from"./index-Bpc5dOQ1.js";import{S as d,a as x,b as j,c as f,d as u}from"./select-CZO_648n.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=n("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=n("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=n("ChevronsLeft",[["path",{d:"m11 17-5-5 5-5",key:"13zhaf"}],["path",{d:"m18 17-5-5 5-5",key:"h8a8et"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=n("ChevronsRight",[["path",{d:"m6 17 5-5-5-5",key:"xnjwq"}],["path",{d:"m13 17 5-5-5-5",key:"17xmmf"}]]);function y({page:s,pageSize:r,total:c,onPage:l,onPageSize:h,selectedCount:m,pageSizeOptions:o=[10,20,50,100]}){const t=Math.max(1,Math.ceil(c/r));return e.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-3 pt-3 text-sm text-muted-foreground",children:[e.jsxs("span",{children:[m!=null?`已选择 ${m} 项, `:"","共 ",c," 项"]}),e.jsxs("div",{className:"flex max-w-full flex-wrap items-center gap-2",children:[h&&e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"每页显示"}),e.jsxs(d,{value:String(r),onValueChange:a=>h(Number(a)),children:[e.jsx(x,{"aria-label":"每页显示条数",className:"h-8 w-[72px]",children:e.jsx(j,{})}),e.jsx(f,{children:o.map(a=>e.jsx(u,{value:String(a),children:a},a))})]})]}),e.jsxs("span",{className:"whitespace-nowrap",children:["第 ",s," 页, 共 ",t," 页"]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(i,{"aria-label":"第一页",variant:"outline",size:"icon",className:"h-8 w-8",disabled:s<=1,onClick:()=>l(1),children:e.jsx(v,{className:"h-4 w-4"})}),e.jsx(i,{"aria-label":"上一页",variant:"outline",size:"icon",className:"h-8 w-8",disabled:s<=1,onClick:()=>l(s-1),children:e.jsx(w,{className:"h-4 w-4"})}),e.jsx(i,{"aria-label":"下一页",variant:"outline",size:"icon",className:"h-8 w-8",disabled:s>=t,onClick:()=>l(s+1),children:e.jsx(p,{className:"h-4 w-4"})}),e.jsx(i,{"aria-label":"最后一页",variant:"outline",size:"icon",className:"h-8 w-8",disabled:s>=t,onClick:()=>l(t),children:e.jsx(N,{className:"h-4 w-4"})})]})]})]})}export{y as D};
