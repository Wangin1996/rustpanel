import{j as e}from"./query-BAGFhzbn.js";import{c,B as i}from"./index-Dvsj1ClM.js";import{S as d,a as x,b as j,c as u,d as f}from"./select-CcrT3T_x.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=c("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=c("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=c("ChevronsLeft",[["path",{d:"m11 17-5-5 5-5",key:"13zhaf"}],["path",{d:"m18 17-5-5 5-5",key:"h8a8et"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=c("ChevronsRight",[["path",{d:"m6 17 5-5-5-5",key:"xnjwq"}],["path",{d:"m13 17 5-5-5-5",key:"17xmmf"}]]);function y({page:s,pageSize:l,total:h,onPage:a,onPageSize:r,selectedCount:m,pageSizeOptions:o=[10,20,50,100]}){const n=Math.max(1,Math.ceil(h/l));return e.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-3 pt-3 text-sm text-muted-foreground",children:[e.jsxs("span",{children:[m!=null?`已选择 ${m} 项, `:"","共 ",h," 项"]}),e.jsxs("div",{className:"flex items-center gap-2",children:[r&&e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"每页显示"}),e.jsxs(d,{value:String(l),onValueChange:t=>r(Number(t)),children:[e.jsx(x,{className:"h-8 w-[72px]",children:e.jsx(j,{})}),e.jsx(u,{children:o.map(t=>e.jsx(f,{value:String(t),children:t},t))})]})]}),e.jsxs("span",{children:["第 ",s," 页, 共 ",n," 页"]}),e.jsx(i,{variant:"outline",size:"icon",className:"h-8 w-8",disabled:s<=1,onClick:()=>a(1),children:e.jsx(p,{className:"h-4 w-4"})}),e.jsx(i,{variant:"outline",size:"icon",className:"h-8 w-8",disabled:s<=1,onClick:()=>a(s-1),children:e.jsx(v,{className:"h-4 w-4"})}),e.jsx(i,{variant:"outline",size:"icon",className:"h-8 w-8",disabled:s>=n,onClick:()=>a(s+1),children:e.jsx(w,{className:"h-4 w-4"})}),e.jsx(i,{variant:"outline",size:"icon",className:"h-8 w-8",disabled:s>=n,onClick:()=>a(n),children:e.jsx(C,{className:"h-4 w-4"})})]})]})}export{y as D};
