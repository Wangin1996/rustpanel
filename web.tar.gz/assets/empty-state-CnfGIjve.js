import{j as e}from"./query-BAGFhzbn.js";import{c as t,d as x}from"./index-CvwNPmqj.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=t("CloudOff",[["path",{d:"m2 2 20 20",key:"1ooewy"}],["path",{d:"M5.782 5.782A7 7 0 0 0 9 19h8.5a4.5 4.5 0 0 0 1.307-.193",key:"yfwify"}],["path",{d:"M21.532 16.5A4.5 4.5 0 0 0 17.5 10h-1.79A7.008 7.008 0 0 0 10 5.07",key:"jlfiyv"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=t("Inbox",[["polyline",{points:"22 12 16 12 14 15 10 15 8 12 2 12",key:"o97t9d"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=t("SearchX",[["path",{d:"m13.5 8.5-5 5",key:"1cs55j"}],["path",{d:"m8.5 8.5 5 5",key:"a8mexj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]),p={empty:y,search:i,error:l};function u({kind:a="empty",icon:r,title:o,description:s,action:c,compact:m,className:n}){const d=r??p[a];return e.jsxs("div",{className:x("flex flex-col items-center justify-center text-center",m?"py-8":"py-14",n),children:[e.jsx("span",{className:"mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-muted text-muted-foreground/70",children:e.jsx(d,{className:"h-5 w-5"})}),e.jsx("p",{className:"text-sm font-medium text-foreground",children:o}),s&&e.jsx("p",{className:"mt-1 max-w-[280px] text-xs text-muted-foreground",children:s}),c&&e.jsx("div",{className:"mt-4",children:c})]})}export{u as E};
